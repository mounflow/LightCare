---
name: Organic Wellness System
colors:
  surface: '#f8faf9'
  surface-dim: '#d8dada'
  surface-bright: '#f8faf9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f3'
  surface-container: '#eceeed'
  surface-container-high: '#e6e9e8'
  surface-container-highest: '#e1e3e2'
  on-surface: '#191c1c'
  on-surface-variant: '#414846'
  inverse-surface: '#2e3131'
  inverse-on-surface: '#eff1f0'
  outline: '#717976'
  outline-variant: '#c1c8c4'
  surface-tint: '#46645c'
  primary: '#16342d'
  on-primary: '#ffffff'
  primary-container: '#2d4b43'
  on-primary-container: '#99bab0'
  inverse-primary: '#adcec3'
  secondary: '#32694e'
  on-secondary: '#ffffff'
  secondary-container: '#b0eac9'
  on-secondary-container: '#356b51'
  tertiary: '#5a170b'
  on-tertiary: '#ffffff'
  tertiary-container: '#782d1f'
  on-tertiary-container: '#ff9782'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c8eadf'
  primary-fixed-dim: '#adcec3'
  on-primary-fixed: '#01201a'
  on-primary-fixed-variant: '#2e4c44'
  secondary-fixed: '#b5efce'
  secondary-fixed-dim: '#9ad3b3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#185038'
  tertiary-fixed: '#ffdad3'
  tertiary-fixed-dim: '#ffb4a5'
  on-tertiary-fixed: '#3f0400'
  on-tertiary-fixed-variant: '#7a2e20'
  background: '#f8faf9'
  on-background: '#191c1c'
  surface-variant: '#e1e3e2'
typography:
  headline-lg:
    fontFamily: Quicksand
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Quicksand
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Quicksand
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  base: 8px
  container-padding-mobile: 20px
  container-padding-desktop: 40px
  gutter: 16px
  section-gap: 32px
---

## Brand & Style

The brand personality is a "gentle companion"—a supportive friend rather than a strict coach. The target audience includes individuals seeking to improve their lifestyle without the anxiety often associated with data-heavy health trackers. The UI evokes an emotional response of calmness, safety, and encouragement.

The design style is a blend of **Soft Minimalism** and **Organic Tactility**. It prioritizes heavy whitespace and a "pillowy" interface that feels soft to the touch. By utilizing extreme roundedness and a muted, nature-inspired palette, the system removes the clinical "edge" of traditional medical apps in favor of a lifestyle-oriented, approachable aesthetic.

## Colors

The palette is rooted in a "Forest & Meadow" concept to ground the user in nature and health.

- **Primary (Deep Forest):** Used for primary text and high-priority branding to establish trust and grounding.
- **Secondary (Sage/Mint):** Used for main interactive elements and subtle container backgrounds.
- **Tertiary (Coral):** Used for highlights and "friendly" alerts. It replaces harsh reds to keep the stress levels low while still drawing attention.
- **Neutral (Off-White/Mist):** The base background color, providing a softer contrast than pure white.
- **Hydration (Soft Blue):** A dedicated color for water tracking to provide immediate visual categorizing.

All colors are applied with a low-vibrancy approach to ensure the UI remains soothing during evening use.

## Typography

The typography strategy uses **Quicksand** for display and headlines to lean into its rounded, friendly geometry. For body text and functional labels, **Plus Jakarta Sans** is used to maintain high readability while echoing the soft, modern curves of the overall design.

- **Headlines:** Set with tight letter spacing and bold weights to feel like "friendly stamps."
- **Body:** Generous line heights are used to ensure the text feels airy and un-cramped.
- **Hierarchy:** We rely on font weight and color (Deep Forest vs. Sage) rather than extreme size shifts to differentiate information levels, keeping the screen's visual energy consistent.

## Layout & Spacing

This design system uses a **Fluid Content Model** centered around nested cards. There is no rigid vertical grid; instead, we rely on a consistent 8px baseline rhythm and significant outer margins.

- **Mobile:** Elements are primarily single-column stacks with 20px safe-area margins.
- **Desktop/Tablet:** Content is centered in a maximum 800px readable container to prevent eye strain. 
- **Grouping:** Use large gaps (32px+) between distinct functional sections to give the "eye" room to breathe, reinforcing the low-stress narrative.

## Elevation & Depth

Depth is communicated through **Soft Tonal Layering** and **Ambient Shadows**. 

- **Surface Tiers:** The base background is the neutral "Mist" color. Primary cards use pure white to pop subtly.
- **Shadows:** Avoid harsh, dark shadows. Use extremely diffused (20-40px blur), low-opacity (5-10%) shadows tinted with the Primary Forest Green to make cards feel like they are floating gently above the surface.
- **Interactions:** When a user taps an element, it should visually "sink" (reduce shadow and scale slightly) to provide tactile, squishy feedback.

## Shapes

The shape language is the core of the "friendly" identity. 

- **Cards and Containers:** Use a minimum of 24px radius (`rounded-xl`).
- **Interactive Elements:** Buttons and input fields should be fully pill-shaped (rounded-full) whenever possible.
- **Icons:** Use icons with rounded terminals and a consistent stroke weight (2px) to match the "hand-drawn but clean" aesthetic. Avoid sharp 90-degree angles in any UI decoration.

## Components

### Rainbow Progress Rings
Rings should have a thick, rounded stroke (12px+). The "unfilled" track should be a very pale version of the stroke color (e.g., 10% opacity). Rings should glow slightly when a goal is reached.

### Friendly Recommendation Cards
These cards use the Secondary Sage color for the background. They feature a large "rounded-lg" icon or illustration on the left and Quicksand Headline-MD on the right. They should never feel like an "ad," but like a helpful tip.

### Floating Action Button (FAB)
The FAB is a large, pill-shaped button located at the bottom center. It uses the Primary Forest Green with a white icon. It should have the most prominent ambient shadow in the system to indicate its importance for logging.

### Emotional Feedback Badges
Small, circular chips with soft emoji-style illustrations. These use a light Coral or Mint tint. They are used to tag moods or energy levels and should feel "collectible" rather than "data points."

### Inputs & Buttons
- **Buttons:** High-contrast (Primary Green with White text) for primary actions; Secondary Sage for secondary actions. Always pill-shaped.
- **Text Inputs:** Light grey backgrounds with no border, using a 16px border-radius and large internal padding.